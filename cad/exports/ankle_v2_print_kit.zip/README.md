# Ankle V2.1 physical prototype

One leg uses: 1 replacement lower leg, 1 sole, 2 identical cheeks,
1 added ST3215 with its stock metal wheels, and the existing knee motor.
Start by printing ONE cheek for the wheel interface.

IMPORTANT: The lower-leg exporter reported two faces skipped due to null
triangulation. A mesh-closure check is awaiting explicit authorization.
Do not treat the lower-leg mesh as cleared for printing yet.
No slicing, physical-fit, strength or motion checks have been performed.

Open cad/docs/ankle-v2-printable.md for the hardware BOM and assembly sequence.
Print meshes: cad/exports/3mf/ and cad/exports/stl/ (millimetres).
Primary geometry: cad/exports/step/. The assembly STEP is a reference only;
print the separate parts, not the whole assembly.

Source excerpts and the parameter ledger are included for inspection.
Regeneration requires the original drobot2 repository, existing ST3215 bay
and immutable vendor STEP, its CAD environment and installed CAD skill.
Review pictures and a live viewer are available in the original workspace;
localhost links work only on that machine.
